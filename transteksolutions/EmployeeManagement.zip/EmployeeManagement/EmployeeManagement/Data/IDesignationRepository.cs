﻿
namespace EmployeeManagement.Data
{
    public interface IDesignationRepository
    {
        List<Designation> GetAllDesignations();
    }
}