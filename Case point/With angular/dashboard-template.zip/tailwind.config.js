module.exports = {
    plugins: [require('@tailwindcss/forms'),]
};
